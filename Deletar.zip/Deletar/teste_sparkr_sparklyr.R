Sys.setenv(SPARK_HOME = "/usr/local/spark")

# Sparklyr
library(sparklyr)
library(dplyr)
sc <- spark_connect(master = "local")
spark_disconnect(sc)
detach("package:dplyr", unload=TRUE)
detach("package:sparklyr", unload=TRUE)

# SparkR
library(SparkR)
sparkR.session(master = "local")
sparkR.conf(SPARK_HOME)
sparkR.stop()
detach("package:SparkR", unload=TRUE)

#Checar estado de execução do Spark no browser: localhost:4040