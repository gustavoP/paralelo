### Script Apresentação

# Configurações globais
Sys.setenv(SPARK_HOME = "/usr/local/spark")
library(tictoc)

######## SPARKLYR #########
library(sparklyr)
library(dplyr)

### Spark com 1 worker ####
# sc <- spark_connect(master = "local")

### Spark com 2 workers ####
cfg <- spark_config()
sc <- spark_connect(master ="spark://jeff-thinkpad:7077", config = cfg)


# carga de arquivo csv
tic("load_data")
teste <- spark_read_csv(sc, name = "wru", path = "/home/jeff/datasets/vra_wu/vra_wu.csv", header = TRUE, delimiter = ",")
toc()
# load_data: 134.058 sec elapsed

# contagem de linhas
tic("count")
count(teste)
toc()
# count: 2.266 sec elapsed




# carga de arquivo csv
tic("load_data")
teste <- spark_read_csv(sc, name = "wru", path = "/home/jeff/datasets/vra_wu/vra_wu.csv", header = TRUE, delimiter = ",")
toc()
# load_data: 134.058 sec elapsed

# contagem de linhas
tic("count")
count(teste)
toc()
# count: 2.266 sec elapsed





