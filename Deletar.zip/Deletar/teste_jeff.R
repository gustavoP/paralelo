### Script Apresentação

library(tictoc)

# SPARKLYR
tic("load_data")
teste <- spark_read_csv(sc, name = "wru", path = "/home/jeff/datasets/vra_wu/vra_wu.csv", header = TRUE, delimiter = ",")
toc()
# load_data: 134.058 sec elapsed

tic("count")
count(teste)
toc()
# count: 2.266 sec elapsed


c1 = filter(teste, ICAO == 'SARJ')
head(teste)

tic("load data")
#vra_wu <- read.df("/home/gustavo/Desktop/vra_wu.csv", "csv", header = "true")
#aerodromos = read.df("/home/gustavo/Desktop/Glossario_de_Aerodromo.csv","csv", header = "true")
vra_wu <- read.df("/home/jeff/datasets/vra_wu/vra_wu.csv", "csv", header = "true")
aerodromos = read.df("/home/jeff/datasets/vra_wu/Glossario_de_Aerodromo.csv","csv", header = "true")
toc()


tic()
vra_wu2 = spark_read_csv(name = "/home/jeff/datasets/vra_wu/vra_wu.csv")
toc()
spark_read_csv(sc=local, name="wra_wu2", path="/home/jeff/datasets/vra_wu/vra_wu.csv", 
               header = TRUE, columns = NULL,
               infer_schema = TRUE, delimiter = ";", quote = "\"",
               escape = "\\", charset = "UTF-8", null_value = NULL,
               options = list(), repartition = 0, memory = TRUE,
               overwrite = TRUE)

spark_read_csv(sc="local", name="wra_wu2", path="/home/jeff/datasets/vra_wu/vra_wu.csv")
persist(vra_wu)
